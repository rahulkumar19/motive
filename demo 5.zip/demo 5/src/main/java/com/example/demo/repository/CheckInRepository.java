package com.example.demo.repository;

import com.example.demo.entities.CheckIn;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;

@Repository
public interface CheckInRepository extends JpaRepository<CheckIn, Long> {


    @Query("select venue_id, count(*) as occ from check_in where check_in_time > :startTime  and check_in_time < :endTime group by venue_id order by occ desc limit 1")
    CheckIn getMostVisitedVenue(LocalDateTime startTime, LocalDateTime endTime);
}
