package com.example.demo.controller;

import com.example.demo.entities.CheckIn;
import com.example.demo.repository.CheckInRepository;
import com.example.demo.util.DatasetReader;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@RestController
@RequestMapping("/api")
public class FileReader {


    @Autowired
    CheckInRepository checkInRepository;

    @PostMapping("/process/file")
    public String processFile(@RequestParam("file")MultipartFile file) throws IOException {
        DatasetReader datasetReader = new DatasetReader(checkInRepository);
        datasetReader.processDataset();
        return "Success";
    }

    @GetMapping("/venue/{startTime}/{endTime}")
    public CheckIn getMostVisitedVenue(@PathVariable String startTime, @PathVariable String endTime){
        LocalDateTime start = LocalDateTime.parse(startTime, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss Z yyyy"));
        LocalDateTime endT =   LocalDateTime.parse(endTime, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss Z yyyy"));
        return checkInRepository.getMostVisitedVenue(start, endT);
    }

    private void processDataset(List<String[]> allRecords) {
        for (String[] record : allRecords) {
            String venue = record[0];
            String checkInTime = record[7];
        }
    }
}
