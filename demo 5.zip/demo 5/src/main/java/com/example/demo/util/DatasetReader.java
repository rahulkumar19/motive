package com.example.demo.util;
import com.example.demo.entities.CheckIn;
import com.example.demo.repository.CheckInRepository;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvException;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import java.util.Formatter;
import java.util.List;

public class DatasetReader {

    CheckInRepository checkInRepository;
    public DatasetReader(CheckInRepository checkInRepository){
        this.checkInRepository = checkInRepository;
    }

    public void processDataset() {
        String csvFilePath = "src/main/resources/dataset.csv";
        try (CSVReader csvReader = new CSVReader(new FileReader(csvFilePath))) {
            int count =0;
            List<String[]> allRecords = csvReader.readAll();
            for (String[] record : allRecords) {
                if(count==0){
                    count++;
                    continue;
                }
                String venue = record[0];
                String checkInTime = record[7];
                CheckIn checkIn = new CheckIn();
                checkIn.setCheckInTime(LocalDateTime.parse(checkInTime, DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss Z yyyy")));
                checkIn.setVenueId(venue);
                checkInRepository.save(checkIn);
            }
        } catch (IOException | CsvException e) {
            e.printStackTrace();
        }
    }
}

